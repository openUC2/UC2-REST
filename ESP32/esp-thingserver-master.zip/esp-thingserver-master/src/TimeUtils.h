#pragma once

#include <Arduino.h>

void beginTimeClient();
String getTimeStampString();
